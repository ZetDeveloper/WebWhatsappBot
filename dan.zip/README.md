Disable Content-Security-Policy in Chromium browers for web application testing.

[Install via the Chrome Web Store](https://chrome.google.com/webstore/detail/disable-content-security/ieelmcmcagommplceebfedjlakkhpden)

## Contributors

* [Phil Grayson](https://github.com/PhilGrayson)
* [Denis Gorbachev](https://github.com/DenisGorbachev)
